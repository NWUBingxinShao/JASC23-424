# MaxENT Model Result Big Data Analysis - Data Stored in - Supplementary Material - All-AUC - Only Selecting Two Calibrated Environmental Layers
# Permutation Importance Result Big Data Analysis
# Install and load the required packages
library(tidyverse)
library(stringr)

# Set the folder path
folder_path <- "REDACTED"

# Get the file names of all CSV files in the folder
csv_files <- list.files(folder_path, pattern = "\\.csv$", full.names = TRUE)

# Use lapply function to read each CSV file and create corresponding data frames, stored in a list
data_frames_list <- lapply(csv_files, readr::read_csv)

# Use lapply function to extract the names of each data frame, matching the pattern of character_character_character from the file names
data_frames_names <- lapply(csv_files, function(x) {
  str_extract(tools::file_path_sans_ext(basename(x)), "\\w+_\\w+_\\w+")
})

# Assign names to each data frame in the list
names(data_frames_list) <- unlist(data_frames_names)

# Extract the data from the "bi_x.tif permutation importance" column of each data frame
contributions_list <- lapply(data_frames_list, function(df) {
  # Get the column names of each data frame
  columns_names <- colnames(df)
  # Select the columns ending with ".tif permutation importance"
  columns_to_extract <- columns_names[str_detect(columns_names, "\\.tif permutation importance$")]
  # Extract the data from these columns
  selected_columns <- df[, columns_to_extract, drop = FALSE]
  return(selected_columns)
})

# Use lapply function to modify column names and add a new column to each data frame in the list
contributions_list <- lapply(names(contributions_list), function(name) {
  df <- contributions_list[[name]]
  # Get the column names of each data frame
  columns_names <- colnames(df)
  # Replace unwanted parts in the column names, such as "bi" with "bi_"
  columns_names <- str_replace(columns_names, "bi_", "bi")
  # Set the column names of each data frame
  colnames(df) <- columns_names
  # Add a new column with the data frame name
  df$Data_Frame_Name <- name
  # Return the modified data frame
  return(df)
})

# Combine the data frames in the list by rows
combined_data <- bind_rows(contributions_list)

# Extract keywords as x-axis labels
x_labels <- gsub(".tif permutation importance", "", names(combined_data))

# Get the column headers of the data frame
col_names <- colnames(combined_data)

# Simplify the column header names using regular expressions, keeping only the part starting with "bi" followed by a number
new_col_names <- sub("^.*\\bbi(\\d+)\\.tif.*$", "bi\\1", col_names)

# Apply the new column headers to the data frame
colnames(combined_data) <- new_col_names

# Extract crop type keywords
combined_data$Crop_Type <- sub("([^_]+)_.*", "\\1", combined_data$Data_Frame_Name)

# Extract keywords
combined_data$Sampling_Method <- sub(".*_(BS|SS|CV).*", "\\1", combined_data$Data_Frame_Name)

# Extract environmental variable feature keywords
combined_data$Environment <- sub(".*_(LH|MH|MH30s|NOW).*", "\\1", combined_data$Data_Frame_Name)

# Select data from the 2nd to the 21st column
selected_data_again <- combined_data[, 1:19]

# Calculate the mean for each variable
means <- colMeans(selected_data_again)

# Sort by mean and select the top 8 variables
sorted_vars <- names(sort(means, decreasing = TRUE)[1:8])

# Create a new data frame with variable names and means
selected_subset_P <- data.frame(Variable = sorted_vars, Mean = means[sorted_vars])

# Select columns to be standardized, excluding non-numeric columns
numeric_columns <- sapply(combined_data, is.numeric)
scaled_data <- scale(combined_data[, numeric_columns])

# Add non-numeric columns back to the standardized data frame
scaled_data <- cbind(combined_data[, !numeric_columns], scaled_data)

# Create a data frame
data <- selected_data_again

# Extract column names
column_names <- colnames(data)

# Set range limits
lower_limit <- 0.05
upper_limit <- 0.95

# Filter the data
data_filtered <- data %>%
summarize(across(everything(), ~ quantile(., c(lower_limit, upper_limit))))

# Load necessary libraries
library(tidyverse)
library(ggcorrplot)

# Set global graphical theme
theme_set(theme_minimal())

# Plot histograms for each column
selected_data_again %>% 
  pivot_longer(cols = everything()) %>%   # Convert data from wide to long format using the pivot_longer function
  ggplot(aes(x = value, fill = name)) +   # Create a plot object using ggplot and set aesthetic mappings
  geom_histogram(bins = 20, color = "black") +  # Plot histograms using geom_histogram
  facet_wrap(~name, scales = "free_x", ncol = 4) +   # Group the plots by columns using facet_wrap
  labs(title = "Histogram of Each Model Parameter",   # Add title and axis labels
       x = "Value",
       y = "Count",
       fill = "Parameter") +
  theme(legend.position = "none",   # Set the graphical theme
        plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        strip.text = element_text(size = 10, face = "bold"))

# Plot density plots for each column
data_filtered %>% 
  pivot_longer(cols = everything()) %>%   # Convert data from wide to long format using the pivot_longer function
  ggplot(aes(x = value, fill = name)) +   # Create a plot object using ggplot and set aesthetic mappings
  geom_density(alpha = 0.5) +   # Plot density plots using geom_density
  facet_wrap(~name, scales = "free_x", ncol = 4) +   # Group the plots by columns using facet_wrap
  labs(title = "Density Plot of Each Model Parameter",   # Add title and axis labels
       x = "Value",
       y = "Density",
       fill = "Parameter") +
  theme(legend.position = "none",   # Set the graphical theme
        plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        strip.text = element_text(size = 10, face = "bold"))

# Plot boxplots for each column
data_filtered %>% 
  pivot_longer(cols = everything()) %>%   # Convert data from wide to long format using the pivot_longer function
  ggplot(aes(x = name, y = value, fill = name)) +   # Create a plot object using ggplot and set aesthetic mappings
  geom_boxplot(outlier.shape = NA) +   # Plot boxplots using geom_boxplot
  coord_flip() +   # Swap x and y axes using coord_flip
  labs(title = "Boxplot of Each Model Parameter",   # Add title and axis labels
       x = "Parameter",
       y = "Value",
       fill = "Parameter") +
  theme(legend.position = "none",   # Set the graphical theme
        plot.title = element_text(size = 14, face = "bold"),
        axis.title = element_text(size = 12),
        axis.text.y = element_text(size = 10, face = "bold"))




