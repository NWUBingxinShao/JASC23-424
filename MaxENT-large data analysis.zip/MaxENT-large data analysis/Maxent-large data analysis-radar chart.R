# Continuing from the previous analysis code to plot a radar chart, distinguishing the selected datasets by C-percent contribution, P-permutation importance, and J-Jackknife
# Within each dataset, sort by the Mean column and add a number column
selected_subset_C <- selected_subset_C %>%
  arrange(desc(Mean)) %>%
  mutate(number = row_number())

selected_subset_P <- selected_subset_P %>%
  arrange(desc(Mean)) %>%
  mutate(number = row_number())

selected_subset_Jack <- selected_subset_Jack %>%
  arrange(desc(Mean)) %>%
  mutate(number = row_number())

library(dplyr)

# Merge datasets using bind_rows from dplyr to maintain independence
merged_data <- bind_rows(selected_subset_C %>% mutate(Source = "C"),
                         selected_subset_P %>% mutate(Source = "P"),
                         selected_subset_Jack %>% mutate(Source = "Jack"))

# Read the CSV file
file_path <- "YOUR_FILE_PATH_HERE"  # Update with your file path
data <- read.csv(file_path)

# Check the structure of the data
str(data)

# Load the dplyr package
library(dplyr)

# Group the data by the Source column and standardize the Mean column
data <- data %>%
  group_by(Source) %>%
  mutate(Mean_Standardized = scale(Mean))

# Add 1 to the values in the Mean_Standardized column
data$Mean_Standardized <- data$Mean_Standardized + 2.5

# Rename the column to SD
colnames(data)[colnames(data) == "Mean_Standardized"] <- "SD"

# Check the structure of the processed data
str(data)

library(fmsb)
library(dplyr)

# Prepare data for radar chart
radar_data <- data %>%
  select(Source, Variable, SD) %>%
  spread(Variable, SD) %>%
  select(-Source)

# Replace missing values with 0.01
radar_data[is.na(radar_data)] <- 0.00

# Create a new dataframe
new_radar_df <- data.frame(
  Source = c("Max", "Min"),
  bi1 = c(5, 0),
  bi10 = c(5, 0),
  bi11 = c(5, 0),
  bi13 = c(5, 0),
  bi19 = c(5, 0),
  bi2 = c(5, 0),
  bi3 = c(5, 0),
  bi4 = c(5, 0),
  bi5 = c(5, 0),
  bi6 = c(5, 0),
  bi7 = c(5, 0),
  bi8 = c(5, 0),
  bi9 = c(5, 0)
)

# Merge data
df <- rbind(new_radar_df, radar_data)

# Set "Source" column data as row names
rownames(df) <- df$Source

# Remove the original "Source" column
df <- df[, -1]

# Plot the radar chart
radarchart(
  df, axistype = 4,
  pcol = c("#00AFBB", "#E7B800", "#FC4E07"), 
  pfcol = scales::alpha(c("#00AFBB", "#E7B800", "#FC4E07"),0.25), 
  plwd = 2, plty = 2,
  seg=4, 
  cglcol = "black", cglty = 5, cglwd = 1.0,
  axislabcol = "black", 
  vlcex = 1.5, vlabels = colnames(C),  # Correct 'colnames(C)' to 'colnames(df)'
  caxislabels = c("Worst", "", "", "", "Best")
)

# Add a horizontal legend
legend(
  x = 0.7, y = 1.2, legend = rownames(df[-c(1,2),]), horiz = TRUE,
  bty = "n", pch = 20 , col = c("#00AFBB", "#E7B800", "#FC4E07"),
  text.col = "black", cex = 1, pt.cex = 2
)